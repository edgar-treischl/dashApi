# dashApi/__init__.py

# Example (optional): expose the FastAPI app directly
# from .main import app
